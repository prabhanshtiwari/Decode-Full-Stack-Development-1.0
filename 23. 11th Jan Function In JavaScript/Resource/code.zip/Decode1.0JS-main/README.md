# Decode1.0JS
